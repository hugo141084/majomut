<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<?php

class clase_recepcion {

    function introduce_movimiento( $cantidad,$productoId, $almacenId,$lote,$fecha_caducidad,$serie,$opcion,$num_inventario) {
        
        
        $array_productos = Session::get('array_productos');
        $num = count($array_productos);
        $array_productos[$num]['PRODUCTO_ID'] = $productoId;
        $producto=new producto();
        $detalle=$producto->listarXid($productoId);
        $array_productos[$num]['CLAVE'] = $detalle->clave;
        $array_productos[$num]['DESCRIPCION'] = $detalle->descripcion;
        $array_productos[$num]['CANTIDAD'] = $cantidad;
        $array_productos[$num]['MEDIDA'] = $detalle->medida;
        //$presentacion=new presentacion();
        //$detalle_presentacion=$presentacion->listarXid($detalle->UNIDAD_ENTRADA);
        $array_productos[$num]['UNIDAD_ENTRADA'] = $detalle->empaque;
        $array_productos[$num]['OPCION']=$opcion;
        if(($detalle->UNIDAD_PAQUETE=="") || ($detalle->UNIDAD_PAQUETE==0)){
        $array_productos[$num]['UNIDAD_PAQUETE']=1;        
        }else{
        $array_productos[$num]['UNIDAD_PAQUETE']=$detalle->UNIDAD_PAQUETE;    
        }
        $loteD=new lote();
        $detalle_lote=$loteD->listarXid($lote);
        $array_productos[$num]['LOTE_CODIGO'] = $detalle_lote->codigo;
        if(($lote!="") and ($serie=="")){
        $array_productos[$num]['LOTE_SERIE'] = $lote;
        }else if(($lote=="") and ($serie!="")){
          $array_productos[$num]['LOTE_SERIE'] = $serie;  
        }  else {
         $array_productos[$num]['LOTE_SERIE'] = "";   
        }
        $array_productos[$num]['FECHA_CADUCIDAD'] = $fecha_caducidad;
        $array_productos[$num]['NUMERO_INVENTARIO']= $num_inventario;
        $array_productos[$num]['ALMACEN_ID']= $almacenId;
          $almacen=new almacen();
        $detalle_almacen=$almacen->listarXid($almacenId);     
        $array_productos[$num]['ALMACEN']= $detalle_almacen->almacen;
        $array_productos[$num]['DESCRIPCION_ALMACEN']= $detalle_almacen->descripcion;
        
        Session::set('array_productos', $array_productos);
    }

    function guarda_movimiento($idSujeto, $importe, $formaPago, $fechaElaboracion, $referencia, $idCobro, $idRecibo, $conceptoDescuento) {


        $array_datos_ventanilla = Session::get('array_datos_ventanilla');
        $longitud = count($array_datos_ventanilla);
        $monto = $importe;
        if ($longitud != 0) {
            for ($num = 0; $num < $longitud; $num++) {
                if ($array_datos_ventanilla[$num]['ID_SUJETO'] == $idSujeto) {
                    if ($monto > 0) {
                        if ($monto >= $array_datos_ventanilla[$num]['IMPORTE_ACTUAL']) {
                            $monto = $monto - $array_datos_ventanilla[$num]['IMPORTE_ACTUAL'];
                            $array_datos_descuento = Session::get('array_datos_descuento');
                            $longitudDescuento = count($array_datos_descuento);
                            if ($longitudDescuento > 0) {
                                for ($des = 0; $des < $longitudDescuento; $des++) {
                                    if ((($array_datos_ventanilla[$num]['CLAVE_CRI']) == ($array_datos_descuento[$des]['CLAVE'])) and (($array_datos_descuento[$des]['ID_SUJETO']) == ($idSujeto))) {

                                        $idDescuento = $array_datos_descuento[$des]['ID'];
                                        $importe = $array_datos_ventanilla[$num]['IMPORTE_ACTUAL'];
                                        $porcentaje = $array_datos_descuento[$des]['PORCENTAJE'];
                                        $importeDescuento = ($importe * $porcentaje) / 100;
                                        $importeNeto = $importe - $importeDescuento;
                                        $importeActual = $importeDescuento;
                                        $resultado = load::model('cuentaCobrar')->insertaCuenta($idSujeto, $importeNeto, $importeActual, $formaPago, $array_datos_ventanilla[$num]['ID_CUENTA'], $array_datos_ventanilla[$num]['ID_PERIODICIDAD'], $array_datos_ventanilla[$num]['CLAVE_CRI'], $fechaElaboracion, $referencia,$idCobro,NULL, $array_datos_ventanilla[$num]['CUENTA_ID']);
                                        $importeActual = 0;
                                        $resultado = load::model('cuentaCobrar')->insertaCuenta($idSujeto, $importeDescuento, $importeActual, $conceptoDescuento, $array_datos_ventanilla[$num]['ID_CUENTA'], $array_datos_ventanilla[$num]['ID_PERIODICIDAD'], $array_datos_ventanilla[$num]['CLAVE_CRI'], $fechaElaboracion, $referencia,$idCobro, $idDescuento, $array_datos_ventanilla[$num]['CUENTA_ID']);
                                        $idCuentaCobrar = $resultado;
                                        $recibosDescuentos = load::Model('recibosDescuentos')->guardarDatos($idRecibo, $idCuentaCobrar, $idDescuento);
                                        $des = $longitudDescuento;
                                    }
                                }
                            } else {                               
                                $importeActual = 0;
                                $resultado = load::model('cuentaCobrar')->insertaCuenta($idSujeto, $array_datos_ventanilla[$num]['IMPORTE_ACTUAL'], $importe_actual, $formaPago, $array_datos_ventanilla[$num]['ID_CUENTA'], $array_datos_ventanilla[$num]['ID_PERIODICIDAD'], $array_datos_ventanilla[$num]['CLAVE_CRI'], $fechaElaboracion, $referencia, $idCobro,NULL, $array_datos_ventanilla[$num]['CUENTA_ID']);
                            }
                         }else {
                            
                            $array_datos_descuento = Session::get('array_datos_descuento');
                            $longitudDescuento = count($array_datos_descuento);
                            if ($longitudDescuento > 0) {
                                for ($des = 0; $des < $longitudDescuento; $des++) {
                                    if ((($array_datos_ventanilla[$num]['CLAVE_CRI']) == ($array_datos_descuento[$des]['CLAVE'])) and (($array_datos_descuento[$des]['ID_SUJETO']) == ($idSujeto))) {
                                      
                                        $idDescuento = $array_datos_descuento[$des]['ID'];
                                        $importe = $array_datos_ventanilla[$num]['IMPORTE_ACTUAL'];
                                        $porcentaje = $array_datos_descuento[$des]['PORCENTAJE'];
                                        $importeDescuento = ($importe * $porcentaje) / 100;
                                        $importeNeto = $importe - $importeDescuento;
                                        $importeActual = $importeDescuento;                                     
                                        //$importeActual=0;
                                        $resultado = load::model('cuentaCobrar')->insertaCuenta($idSujeto, $importeNeto, $importeActual, $formaPago, $array_datos_ventanilla[$num]['ID_CUENTA'], $array_datos_ventanilla[$num]['ID_PERIODICIDAD'], $array_datos_ventanilla[$num]['CLAVE_CRI'], $fechaElaboracion, $referencia,$idCobro,NULL,$array_datos_ventanilla[$num]['CUENTA_ID']);
                                        $importeActual=0;  
                                        $resultado = load::model('cuentaCobrar')->insertaCuenta($idSujeto, $importeDescuento,$importeActual, $conceptoDescuento, $array_datos_ventanilla[$num]['ID_CUENTA'], $array_datos_ventanilla[$num]['ID_PERIODICIDAD'], $array_datos_ventanilla[$num]['CLAVE_CRI'], $fechaElaboracion, $referencia,$idCobro, $idDescuento, $array_datos_ventanilla[$num]['CUENTA_ID']);
                                        $idCuentaCobrar = $resultado;
                                        $recibosDescuentos = load::Model('recibosDescuentos')->guardarDatos($idRecibo, $idCuentaCobrar, $idDescuento);
                                        $des = $longitudDescuento;
                                    }
                                }
                            } else {
                                $importe = $array_datos_ventanilla[$num]['IMPORTE_ACTUAL'];
                                $importeActual = 0;
                                $resultado = load::model('cuentaCobrar')->insertaCuenta($idSujeto, $monto, $importeActual, $formaPago, $array_datos_ventanilla[$num]['ID_CUENTA'], $array_datos_ventanilla[$num]['ID_PERIODICIDAD'], $array_datos_ventanilla[$num]['CLAVE_CRI'], $fechaElaboracion, $referencia, $idCobro,NULL, $array_datos_ventanilla[$num]['CUENTA_ID']);
                                $monto = 0;
                            }
                        }
                    }
                }
            }
            return $mensaje = "inserto";
        } else {
            return $mensaje = "NoExiste";
        }
    }

    function quita_movimiento($linea) {
        $array_productos = Session::get('array_productos');
        unset($array_productos[$linea]);
        $array_productos = array_values($array_productos);
        Session::set('array_productos', $array_productos);
    }

}

?>

<?php
?>
<?php

$conceptoDescuento=6;
$conceptoRecargo=7;
$conceptoCancelacion=9;
$conceptoEfectivo=1;
$emisionCheque=8;
$raiz = '../../../cfdi/archivos';
?>
